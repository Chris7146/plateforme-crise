# Maquettes de référence

Cinq écrans validés, à ouvrir dans un navigateur. Ce sont des maquettes statiques :
la structure, la hiérarchie visuelle, le code couleur et les libellés font référence ;
les données affichées sont fictives (scénario « CHU de Valmont », nom de travail SIM//CRISE).

| Fichier | Écran | Lot |
|---|---|---|
| `accueil.html` | Accueil et acceptation des conditions | 2 |
| `participant.html` | Interface participant pendant une étape | 3 |
| `console.html` | Console de pilotage de l'animateur | 4 |
| `editeur-etapes.html` | Éditeur d'étapes (modèle / variante) | 1 |
| `retex.html` | Vue RETEX (frise, rejeu, détail d'étape) | 5 |

Les icônes proviennent de Tabler Icons ; la police de référence est une chasse fixe.
